@bender-tags: 12440, tc, 4.5.8
@bender-ui: collapsed
@bender-ckeditor-plugins: wysiwygarea, toolbar, colorbutton, floatingspace

### Scenario 1:

1. Click *Text Color* button in Editor 1.
	* **Expected**: There is no *Automatic* option.
1. Click *Background Color* button in Editor 1.
	* **Expected**: There is no *Automatic* option.

### Scenario 2:

1. Click *Text Color* button in Editor 2.
	* **Expected**: There is *Automatic* option.
1. Click *Background Color* button in Editor 2.
	* **Expected**: There is *Automatic* option.
